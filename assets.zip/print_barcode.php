<?php
include_once 'includes/head.php';
	if(ISSET($_REQUEST['id'])){
		$fetchproduct=fetchRecord($dbc,"product", "product_id",base64_decode($_REQUEST['id']));

for($i=1;$i<=1;$i++){
	
echo "<div class='bg-white printtest ' style='width:auto;height:auto;text-align:center;position:fixed;top:0px;'>

<img alt='testing' src='barcode.php?codetype=Code128&size=50&text=".$fetchproduct['product_code']."&print=false' class='img-fluid  '> <p class='text-center  border-bottom border-dark mb-0'>".$fetchproduct['product_code']."</p><p class='text-center p-0 m-0 border-top'>Price :".$fetchproduct['current_rate']."</p></div>";
    ?>
   
    <?php
}
	}
?>
<style>
    @media print {
  .printtest {page-break-after: always;}
}
</style>


<?php 	include_once 'includes/foot.php'; ?>