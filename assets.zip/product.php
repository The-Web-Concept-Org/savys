<!DOCTYPE html>
<html lang="en">
<?php include_once 'includes/head.php'; 
if (isset($_REQUEST['edit_product_id'])) {
 $fetchproduct=fetchRecord($dbc,"product", "product_id",base64_decode($_REQUEST['edit_product_id']));


} $btn_name=isset($_REQUEST['edit_product_id'])?"Update":"Add";

?>
<style type="text/css">
  .badge{
    font-size: 15px;
  }
</style>
  <body class="horizontal light  ">
    <div class="wrapper">
  <?php include_once 'includes/header.php'; ?>
      <main role="main" class="main-content">
        <div class="container-fluid">
          <div class="card">
            <div class="card-header card-bg" align="center">

            <div class="row">
              <div class="col-12 mx-auto h4">
                <b class="text-center card-text">Product Management</b>
           
             <a href="stock.php?type=simple" class="btn btn-admin float-right btn-sm mx-1">Print Stock</a>
             <a href="stock.php?type=amount" class="btn btn-admin float-right btn-sm mx-1">Print Stock With Amount</a>
              
                 <a href="product.php?act=add" class="btn btn-admin float-right btn-sm mx-1">Add New</a>
              </div>
            </div>
  
          </div>
             <?php if (@$_REQUEST['act']=="add"): ?>
             <div class="card-body">  
            <form action="php_action/custom_action.php" id="add_product_fm" method="POST" enctype="multipart/form-data">
              <input type="hidden" name="action" value="product_module">
              <input type="hidden" name="product_id" value="<?=@base64_encode($fetchproduct['product_id'])?>">
              <input type="hidden" id="product_add_from" value="page">


                 <div class="form-group row">
                   <div class="col-sm-4 mb-3 mb-sm-0">
                      <label for="">Product Barcode</label>
                      <input autofocus type="text" class="form-control" id="product_code" placeholder="Scan the Product Barcode" name="product_code" autocomplete="off" required value="<?=@$fetchproduct['product_code']?>">                       
                      </div>
                      <div class="col-sm-2 mb-3 mb-sm-0">
                        <button type="button" id="generate_code" class="btn btn-admin2 mt-4">Generate Barcode</button>
                       </div>
                    <div class="col-sm-3 mb-3 mb-sm-0">
                      <label for="">Product Name</label>
                      <input type="text" class="form-control" id="product_name" placeholder="Product Name" name="product_name" autocomplete="off" required value="<?=@$fetchproduct['product_name']?>">                       
                      </div>
                      
                      <div class="col-sm-3 mb-3 mb-sm-0">
                      <label for="">Product Name urdu</label>
                      <input type="text" class="form-control" id="product_name_urdu" placeholder="Product Name" name="product_name_urdu" autocomplete="off" required value="<?=@$fetchproduct['product_name_urdu']?>">                       
                      </div>
                     
                       
                </div>
                  
                      <div class="form-group row">
                       <div class="col-sm-5">
                         <label for="">Product Brand</label>
                        <select class="form-control searchableSelect tableData" required name="brand_id" id="tableData"    size="1" >
                          <option    value="">Select Brand</option>
                          <?php
                            $result=mysqli_query($dbc,"select * from brands");
                             while($row=mysqli_fetch_array($result)){ 
                          ?>
                    
                      <option  <?=@($fetchproduct['brand_id']!=$row["brand_id"])?"":"selected"?>  value="<?=$row["brand_id"]?>"><?=$row["brand_name"]?></option>

                      <?php   } ?>
                         </select>
                      </div>
                      <div class="col-1 col-md-1">
                      <label class="invisible d-block">.</label>
                        <button type="button"  class="btn btn-success btn-sm" data-toggle="modal" data-target="#add_brand_modal"> <i class="fa fa-plus"></i> </button>
                    </div>
                      <div class="col-sm-5">
                         <label for="">Product Category</label>
                          <select class="form-control searchableSelect"   required name="category_id" id="tableData1" size="1"   >
                          <option    value="">Select Category</option>
                          <?php
                             $result=mysqli_query($dbc,"select * from categories");
                             while($row=mysqli_fetch_array($result)){ 
                          ?>
                          <option data-price="<?=$row["category_price"]?>"  <?=@($fetchproduct['category_id']!=$row["categories_id"])?"":"selected"?>  value="<?=$row["categories_id"]?>"><?=$row["categories_name"]?></option>
                      <?php   } ?>
                         </select>
                    </div>
                    <div class="col-1 col-md-1">
                      <label class="invisible d-block">.</label>
                        <button type="button"  class="btn btn-danger btn-sm" data-toggle="modal" data-target="#add_category_modal"> <i class="fa fa-plus"></i> </button>
                    </div>
               </div>

                 <div class="form-group row">
                  <div class="col-sm-2 mb-3 mb-sm-0">
                      <label for=""> Rate</label>
                      <input type="number" min="0" step="0.0001" class="form-control" id="current_rate" placeholder=" Rate" name="current_rate"  autocomplete="off" required value="<?=@$fetchproduct['current_rate']?>">                       
                      </div>
                      <div class="col-sm-2 mb-3 mb-sm-0">
                           <label for="">Wholesale Rate</label>
                          <input type="number" min="0" step="0.0001" class="form-control" id="f_days" placeholder=" Whole sale rate" name="f_days"  autocomplete="off" required value="<?=@$fetchproduct['f_days']?>">    
                      </div>
                  
                       <div class="col-sm-4 mb-3">
                         <label for="">Product Alert on Quantity</label>
                        <input type="number" min="1" required class="form-control" value="<?=(empty($fetchproduct))?10:$fetchproduct['alert_at']?>" id="alert_at" placeholder="Product Stock Alert" autocomplete="off" name="alert_at" >
                      </div>
                      <div class="col-sm-4 mb-3">
                        <label>Product Image</label>

                            <input type="file" class="form-control" id="product_image" name="product_image" accept="image/*">
                      </div>
                  
                      
                </div>
                  <div class="form-group row">
                    <div class="col-sm-6 mb-3 mb-sm-0">
                      <label for="">Product Description</label>
                       
                      <input type="text"  class="form-control" name="product_description" placeholder="Product Description" autocomplete="off" value="<?=@$fetchproduct['product_description']?>">       
                      </div>
                      <div class="col-sm-6 mb-3 mb-sm-0">
                        
                         <label for="">Status</label>
                        <select class="form-control" required name="availability" id="availability">
                          <option    value="1">Available</option>
                          <option    value="0">Not Available</option>
                         </select>
                      
                      </div>
                </div>
                  <button class="btn btn-admin float-right" type="submit" id="add_product_btn">Save</button>             
            </form>
          </div>
           <?php else: ?>
           <div class="card-body">
           
                
              <table class="table dataTable col-12" style="width: 100%" id="product_tb">
              <thead>
                <tr>
                <th>#</th>
                <th>barcode</th>
                <th>Name</th>
                  <th>Name urdu</th>
                <th>Brand/Category</th>
                <th>Selling Price</th>
                <th>Wholesale Price</th>
               
                <?php   if ($get_company['stock_manage']==1):?>
                <th>Quanity instock</th>
              <?php   endif; ?>
                <th class="d-print-none
">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $q=mysqli_query($dbc,"SELECT * FROM product WHERE status=1 ");
                $c=0;
                      while ($r=mysqli_fetch_assoc($q)) {
                   @$brandFetched=fetchRecord($dbc,"brands","brand_id",$r['brand_id']);
                  @$categoryFetched=fetchRecord($dbc,"categories","categories_id",$r['category_id']);
                        $c++;
                 ?>
                <tr>
                  <td><?=$c?></td>
                  <td><?=$r['product_code']?></td>
                  <td><?=$r['product_name']?></td>
                  <td><?=$r['product_name_urdu']?></td>
                  <td><?=$brandFetched['brand_name']?>/<?=$categoryFetched['categories_name']?></td>
                  <td><?=$r['current_rate']?>
                   <td><?=$r['f_days']?>
                  </td>
               
                  <?php if ($get_company['stock_manage']==1):?>
                    <?php if ($r['quantity_instock']>$r['alert_at']):?>
                    <td >

                      <span class="badge p-1 badge-success d-print-none
"><?=$r['quantity_instock']?></span>  </td>
                    <?php   else: ?>
                       <td ><span class="badge p-1  badge-danger"><?=$r['quantity_instock']?></span> </td>

                      <?php   endif; ?>
                  <?php   endif; ?>
                  <td class="d-print-none">
             
          <?php if (@$userPrivileges['nav_edit']==1 || $fetchedUserRole=="admin"): ?>
                            <form action="product.php?act=add" method="POST">
                              <input type="hidden" name="edit_product_id" value="<?=base64_encode($r['product_id'])?>">
                              <button type="submit" class="btn btn-admin btn-sm m-1 d-inline-block" >Edit</button>
                            </form>
               <?php   endif ?>
               <?php if (@$userPrivileges['nav_delete']==1 || $fetchedUserRole=="admin"): ?>
                        <button type="button" onclick="deleteAlert('<?=$r['product_id']?>','product','product_id','product_tb')" class="btn btn-admin2 btn-sm  d-inline-block" >Delete</button>
                      
               <?php   endif ?>
               <a href="print_barcode.php?id=<?=base64_encode($r['product_id'])?>" class="btn btn-primary btn-sm">Barcode</a>
                  </td>

                </tr>
              <?php } ?>
              </tbody>
            </table>
            
            
             <?php endif ?>
           </div>
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
       
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    
  </body>
</html>
<?php include_once 'includes/foot.php'; ?>
<script type="text/javascript">
  <?php if ($_REQUEST['act']=="add" && !isset($_REQUEST['edit_product_id'])) { ?>
     sweeetalert("Before Scanning Barcode 1st focus on Product Barcode Input then Scan Barcode or Generate it Manually","error",2500);
    <?php } ?>
  document.addEventListener("keypress", function(e) {
  var prodd=  document.activeElement.id;
  //   $('#add_product_btn').prop("disabled",true);
      var input = document.querySelector("#product_code");
          var product_name = document.querySelector("#product_name");
          if (product_name!== document.activeElement && input.value=='') {
 //   if(e.target.tagName !== "INPUT" && e.target.tagName !== "SELECT"){
  if (input !== document.activeElement && e.target.id !== "product_code") {
    
   //e.target.tagName !== "INPUT"
  //  input.focus();
   // input.value = e.key;

      //console.log("f not");

  

  }else{
   // e.preventDefault();
  
    var typingTimer;                //timer identifier
var doneTypingInterval = 1000;  //time in ms, 5 second for example
clearTimeout(typingTimer);
  typingTimer = setTimeout(doneTyping, doneTypingInterval);

     // console.log("f yes");
  }
       //$('#add_product_btn').prop("disabled",false);
//}
}
});
  function doneTyping () {
   //console.log("doooo some");
  // $('#product_code').prop("readonly",true);
      document.querySelector("#product_name").focus();

}
</script>
